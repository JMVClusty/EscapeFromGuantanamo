package mapPrison;

public enum TypePiece {
	cellule, couloir, toilette, douches, bureau,
	CentralSecurite, cours,refectoire, sortie;

}


